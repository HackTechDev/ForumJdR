-- MySQL dump 10.13  Distrib 5.5.46, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: fjr
-- ------------------------------------------------------
-- Server version	5.5.46-0ubuntu0.14.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `fjr_auth_access`
--

LOCK TABLES `fjr_auth_access` WRITE;
/*!40000 ALTER TABLE `fjr_auth_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `fjr_auth_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_banlist`
--

LOCK TABLES `fjr_banlist` WRITE;
/*!40000 ALTER TABLE `fjr_banlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `fjr_banlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_categories`
--

LOCK TABLES `fjr_categories` WRITE;
/*!40000 ALTER TABLE `fjr_categories` DISABLE KEYS */;
INSERT INTO `fjr_categories` VALUES (1,'Test category 1',10);
/*!40000 ALTER TABLE `fjr_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_config`
--

LOCK TABLES `fjr_config` WRITE;
/*!40000 ALTER TABLE `fjr_config` DISABLE KEYS */;
INSERT INTO `fjr_config` VALUES ('allow_autologin','1'),('allow_avatar_local','0'),('allow_avatar_remote','0'),('allow_avatar_upload','0'),('allow_bbcode','1'),('allow_html','0'),('allow_html_tags','b,i,u,pre'),('allow_namechange','0'),('allow_sig','1'),('allow_smilies','1'),('allow_theme_create','0'),('avatar_filesize','6144'),('avatar_gallery_path','images/avatars/gallery'),('avatar_max_height','80'),('avatar_max_width','80'),('avatar_path','images/avatars'),('board_disable','0'),('board_email','lesanglierdesardennes@gmail.com'),('board_email_form','0'),('board_email_sig','Thanks, The Management'),('board_startdate','1448487907'),('board_timezone','0'),('config_id','1'),('cookie_domain',''),('cookie_name','phpbb2mysql'),('cookie_path','/'),('cookie_secure','0'),('coppa_fax',''),('coppa_mail',''),('default_dateformat','D M d, Y g:i a'),('default_lang','english'),('default_style','1'),('enable_confirm','1'),('flood_interval','15'),('gzip_compress','0'),('hot_threshold','25'),('login_reset_time','30'),('max_autologin_time','0'),('max_inbox_privmsgs','50'),('max_login_attempts','5'),('max_poll_options','10'),('max_savebox_privmsgs','50'),('max_sentbox_privmsgs','25'),('max_sig_chars','255'),('override_user_style','0'),('posts_per_page','15'),('privmsg_disable','0'),('prune_enable','1'),('rand_seed','aa68e28244e3e1dae1be68f58dc8aca6'),('record_online_date','1448487983'),('record_online_users','1'),('require_activation','0'),('script_path','/fjr/'),('search_flood_interval','15'),('search_min_chars','3'),('sendmail_fix','0'),('server_name','localhost'),('server_port','80'),('session_length','3600'),('sitename','yourdomain.com'),('site_desc','A _little_ text to describe your forum'),('smilies_path','images/smiles'),('smtp_delivery','0'),('smtp_host',''),('smtp_password',''),('smtp_username',''),('topics_per_page','50'),('version','.0.23');
/*!40000 ALTER TABLE `fjr_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_confirm`
--

LOCK TABLES `fjr_confirm` WRITE;
/*!40000 ALTER TABLE `fjr_confirm` DISABLE KEYS */;
/*!40000 ALTER TABLE `fjr_confirm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_disallow`
--

LOCK TABLES `fjr_disallow` WRITE;
/*!40000 ALTER TABLE `fjr_disallow` DISABLE KEYS */;
/*!40000 ALTER TABLE `fjr_disallow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_forum_prune`
--

LOCK TABLES `fjr_forum_prune` WRITE;
/*!40000 ALTER TABLE `fjr_forum_prune` DISABLE KEYS */;
/*!40000 ALTER TABLE `fjr_forum_prune` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_forums`
--

LOCK TABLES `fjr_forums` WRITE;
/*!40000 ALTER TABLE `fjr_forums` DISABLE KEYS */;
INSERT INTO `fjr_forums` VALUES (1,1,'Test Forum 1','This is just a test forum.',0,10,1,1,1,NULL,0,0,0,1,1,1,1,3,3,1,1,3);
/*!40000 ALTER TABLE `fjr_forums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_groups`
--

LOCK TABLES `fjr_groups` WRITE;
/*!40000 ALTER TABLE `fjr_groups` DISABLE KEYS */;
INSERT INTO `fjr_groups` VALUES (1,1,'Anonymous','Personal User',0,1),(2,1,'Admin','Personal User',0,1);
/*!40000 ALTER TABLE `fjr_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_posts`
--

LOCK TABLES `fjr_posts` WRITE;
/*!40000 ALTER TABLE `fjr_posts` DISABLE KEYS */;
INSERT INTO `fjr_posts` VALUES (1,1,1,2,972086460,'7F000001',NULL,1,0,1,1,NULL,0);
/*!40000 ALTER TABLE `fjr_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_posts_text`
--

LOCK TABLES `fjr_posts_text` WRITE;
/*!40000 ALTER TABLE `fjr_posts_text` DISABLE KEYS */;
INSERT INTO `fjr_posts_text` VALUES (1,'',NULL,'This is an example post in your phpBB 2 installation. You may delete this post, this topic and even this forum if you like since everything seems to be working!');
/*!40000 ALTER TABLE `fjr_posts_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_privmsgs`
--

LOCK TABLES `fjr_privmsgs` WRITE;
/*!40000 ALTER TABLE `fjr_privmsgs` DISABLE KEYS */;
/*!40000 ALTER TABLE `fjr_privmsgs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_privmsgs_text`
--

LOCK TABLES `fjr_privmsgs_text` WRITE;
/*!40000 ALTER TABLE `fjr_privmsgs_text` DISABLE KEYS */;
/*!40000 ALTER TABLE `fjr_privmsgs_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_ranks`
--

LOCK TABLES `fjr_ranks` WRITE;
/*!40000 ALTER TABLE `fjr_ranks` DISABLE KEYS */;
INSERT INTO `fjr_ranks` VALUES (1,'Site Admin',-1,1,NULL);
/*!40000 ALTER TABLE `fjr_ranks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_search_results`
--

LOCK TABLES `fjr_search_results` WRITE;
/*!40000 ALTER TABLE `fjr_search_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `fjr_search_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_search_wordlist`
--

LOCK TABLES `fjr_search_wordlist` WRITE;
/*!40000 ALTER TABLE `fjr_search_wordlist` DISABLE KEYS */;
INSERT INTO `fjr_search_wordlist` VALUES ('delete',5,0),('everything',9,0),('example',1,0),('forum',7,0),('installation',4,0),('phpbb',3,0),('post',2,0),('seems',10,0),('since',8,0),('topic',6,0),('welcome',12,0),('working',11,0);
/*!40000 ALTER TABLE `fjr_search_wordlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_search_wordmatch`
--

LOCK TABLES `fjr_search_wordmatch` WRITE;
/*!40000 ALTER TABLE `fjr_search_wordmatch` DISABLE KEYS */;
INSERT INTO `fjr_search_wordmatch` VALUES (1,1,0),(1,2,0),(1,3,0),(1,4,0),(1,5,0),(1,6,0),(1,7,0),(1,8,0),(1,9,0),(1,10,0),(1,11,0),(1,12,1),(1,3,1);
/*!40000 ALTER TABLE `fjr_search_wordmatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_sessions`
--

LOCK TABLES `fjr_sessions` WRITE;
/*!40000 ALTER TABLE `fjr_sessions` DISABLE KEYS */;
INSERT INTO `fjr_sessions` VALUES ('5b6309d8d833d0302e976a14deff4331',2,1448487996,1448488087,'7f000001',0,1,0);
/*!40000 ALTER TABLE `fjr_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_sessions_keys`
--

LOCK TABLES `fjr_sessions_keys` WRITE;
/*!40000 ALTER TABLE `fjr_sessions_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `fjr_sessions_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_smilies`
--

LOCK TABLES `fjr_smilies` WRITE;
/*!40000 ALTER TABLE `fjr_smilies` DISABLE KEYS */;
INSERT INTO `fjr_smilies` VALUES (1,':D','icon_biggrin.gif','Very Happy'),(2,':-D','icon_biggrin.gif','Very Happy'),(3,':grin:','icon_biggrin.gif','Very Happy'),(4,':)','icon_smile.gif','Smile'),(5,':-)','icon_smile.gif','Smile'),(6,':smile:','icon_smile.gif','Smile'),(7,':(','icon_sad.gif','Sad'),(8,':-(','icon_sad.gif','Sad'),(9,':sad:','icon_sad.gif','Sad'),(10,':o','icon_surprised.gif','Surprised'),(11,':-o','icon_surprised.gif','Surprised'),(12,':eek:','icon_surprised.gif','Surprised'),(13,':shock:','icon_eek.gif','Shocked'),(14,':?','icon_confused.gif','Confused'),(15,':-?','icon_confused.gif','Confused'),(16,':???:','icon_confused.gif','Confused'),(17,'8)','icon_cool.gif','Cool'),(18,'8-)','icon_cool.gif','Cool'),(19,':cool:','icon_cool.gif','Cool'),(20,':lol:','icon_lol.gif','Laughing'),(21,':x','icon_mad.gif','Mad'),(22,':-x','icon_mad.gif','Mad'),(23,':mad:','icon_mad.gif','Mad'),(24,':P','icon_razz.gif','Razz'),(25,':-P','icon_razz.gif','Razz'),(26,':razz:','icon_razz.gif','Razz'),(27,':oops:','icon_redface.gif','Embarassed'),(28,':cry:','icon_cry.gif','Crying or Very sad'),(29,':evil:','icon_evil.gif','Evil or Very Mad'),(30,':twisted:','icon_twisted.gif','Twisted Evil'),(31,':roll:','icon_rolleyes.gif','Rolling Eyes'),(32,':wink:','icon_wink.gif','Wink'),(33,';)','icon_wink.gif','Wink'),(34,';-)','icon_wink.gif','Wink'),(35,':!:','icon_exclaim.gif','Exclamation'),(36,':?:','icon_question.gif','Question'),(37,':idea:','icon_idea.gif','Idea'),(38,':arrow:','icon_arrow.gif','Arrow'),(39,':|','icon_neutral.gif','Neutral'),(40,':-|','icon_neutral.gif','Neutral'),(41,':neutral:','icon_neutral.gif','Neutral'),(42,':mrgreen:','icon_mrgreen.gif','Mr. Green');
/*!40000 ALTER TABLE `fjr_smilies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_themes`
--

LOCK TABLES `fjr_themes` WRITE;
/*!40000 ALTER TABLE `fjr_themes` DISABLE KEYS */;
INSERT INTO `fjr_themes` VALUES (1,'subSilver','subSilver','subSilver.css','','E5E5E5','000000','006699','5493B4','','DD6900','EFEFEF','DEE3E7','D1D7DC','','','','98AAB1','006699','FFFFFF','cellpic1.gif','cellpic3.gif','cellpic2.jpg','FAFAFA','FFFFFF','','row1','row2','','Verdana, Arial, Helvetica, sans-serif','Trebuchet MS','Courier, \'Courier New\', sans-serif',10,11,12,'444444','006600','FFA34F','','','',NULL,NULL);
/*!40000 ALTER TABLE `fjr_themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_themes_name`
--

LOCK TABLES `fjr_themes_name` WRITE;
/*!40000 ALTER TABLE `fjr_themes_name` DISABLE KEYS */;
INSERT INTO `fjr_themes_name` VALUES (1,'The lightest row colour','The medium row color','The darkest row colour','','','','Border round the whole page','Outer table border','Inner table border','Silver gradient picture','Blue gradient picture','Fade-out gradient on index','Background for quote boxes','All white areas','','Background for topic posts','2nd background for topic posts','','Main fonts','Additional topic title font','Form fonts','Smallest font size','Medium font size','Normal font size (post body etc)','Quote & copyright text','Code text colour','Main table header text colour','','','');
/*!40000 ALTER TABLE `fjr_themes_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_topics`
--

LOCK TABLES `fjr_topics` WRITE;
/*!40000 ALTER TABLE `fjr_topics` DISABLE KEYS */;
INSERT INTO `fjr_topics` VALUES (1,1,'Welcome to phpBB 2',2,972086460,0,0,0,0,0,1,1,0);
/*!40000 ALTER TABLE `fjr_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_topics_watch`
--

LOCK TABLES `fjr_topics_watch` WRITE;
/*!40000 ALTER TABLE `fjr_topics_watch` DISABLE KEYS */;
/*!40000 ALTER TABLE `fjr_topics_watch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_user_group`
--

LOCK TABLES `fjr_user_group` WRITE;
/*!40000 ALTER TABLE `fjr_user_group` DISABLE KEYS */;
INSERT INTO `fjr_user_group` VALUES (1,-1,0),(2,2,0);
/*!40000 ALTER TABLE `fjr_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_users`
--

LOCK TABLES `fjr_users` WRITE;
/*!40000 ALTER TABLE `fjr_users` DISABLE KEYS */;
INSERT INTO `fjr_users` VALUES (-1,0,'Anonymous','',0,0,0,1448487907,0,0,0.00,NULL,'','',0,0,0,0,0,NULL,0,0,1,1,1,1,0,1,0,1,0,NULL,'',0,'','','','','',NULL,'','','','','','',''),(2,1,'Administrateur','740ea7afcc423a85093bd7e81bb0adbf',1448488087,0,1448487996,1448487907,1,1,0.00,1,'english','d M Y h:i a',0,0,0,0,0,NULL,1,0,0,1,1,1,1,1,0,1,1,1,'',0,'lesanglierdesardennes@gmail.com','','','','',NULL,'','','','','','','');
/*!40000 ALTER TABLE `fjr_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_vote_desc`
--

LOCK TABLES `fjr_vote_desc` WRITE;
/*!40000 ALTER TABLE `fjr_vote_desc` DISABLE KEYS */;
/*!40000 ALTER TABLE `fjr_vote_desc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_vote_results`
--

LOCK TABLES `fjr_vote_results` WRITE;
/*!40000 ALTER TABLE `fjr_vote_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `fjr_vote_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_vote_voters`
--

LOCK TABLES `fjr_vote_voters` WRITE;
/*!40000 ALTER TABLE `fjr_vote_voters` DISABLE KEYS */;
/*!40000 ALTER TABLE `fjr_vote_voters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fjr_words`
--

LOCK TABLES `fjr_words` WRITE;
/*!40000 ALTER TABLE `fjr_words` DISABLE KEYS */;
/*!40000 ALTER TABLE `fjr_words` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-25 22:51:05
